<script>
  // Pobierz listę i przycisk, który ją wywołuje
    var dropdownList = document.querySelector('.dropdown-list');
    var toggleButton = document.querySelector('#toggle-button');

    // Dodaj obsługę kliknięcia do przycisku
    toggleButton.addEventListener('click', function() {
    if (dropdownList.style.display === 'none' || dropdownList.style.display === '') {
        dropdownList.style.display = 'block';
    } else {
        dropdownList.style.display = 'none';
    }
  });
</script>